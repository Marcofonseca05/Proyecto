



//document.getElementById("btn btn-primary").innerHTML=localStorage.getItem("texto")

  //document.getElementById("boton").addEventListener("click",store)
  //store();


// guardar datos
   // localStorage.setItem("nombre", "dato");

 // leer datos
    //var miDato = localStorage.getItem("#name");
