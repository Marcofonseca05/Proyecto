//baner


//pablin

function traerPeliculas() {
  fetch("peliculas.json")
    .then(respuesta => respuesta.json())
    .then(datosEst => {
      escribe = ``
      console.log("dataEst", datosEst);
      for (peli of datosEst.pelis) {
        document.getElementById("acaPostre").innerHTML = escribe +=
          `<div class='col-4'>
                    <img src='${peli.imagen}'  style='width:200px; height: 200px'>
                    <h3>${peli.nombre}</h3> 
                </div>`
      }
      //mostrarPeliculas(datosEst);
    }).catch(error => {
      console.log("Error", error.message);
    });

};

traerPeliculas();

//buscador

function buscar() {
  var buscador = document.getElementById("search").value;
  fetch("peliculas.json")
    .then(respuesta => respuesta.json())
    .then(data => {
      tumadre = ``
      document.getElementsById("peliculas").innerHTML = tumadre
      for (peli of data.pelis) {
        document.getElementsById("peliculas").innerHTML = tumadre +=
          `<div class='col-2'>
               <img src='${peli.imagen}'  style='width:200px; height: 300px'>
               <h3>${peli.nombre}</h3> 
               <h3>${peli.genero}</h3> 
           </div>`
      }
      //mostrarPeliculas(datosEst);
    }).catch(error => {
      console.log("Error", error.message);
    });
    
    
    document.getElementById("search").addEventListener("click,search")
};


